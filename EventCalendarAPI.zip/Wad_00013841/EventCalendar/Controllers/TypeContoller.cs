﻿using EventCalendar.Repositories;
using Microsoft.AspNetCore.Mvc;

namespace EventCalendar.Controllers
{

    [Route("api/[controller]/[action]")]
    [ApiController]
    public class TypeContoller: ControllerBase
    {
        private readonly IRepository<Models.Category> _repository;
        public TypeContoller(IRepository<Models.Category> repository)
        {
            _repository = repository;
        }







        // GET: api/<CategoryController>
        [HttpGet]
        public async Task<IEnumerable<Models.Category>> Get()
        {
            return await _repository.GetAllAsync();
        }








        // GET api/<CategoryController>/5
        [HttpGet("{id}")]
        public async Task<IActionResult> GetByID(int id)
        {
            var resultedCategory = await _repository.GetByIDAsync(id);
            if (resultedCategory == null)
            {
                return NotFound();
            }
            else
            {
                return Ok(resultedCategory);
            }
        }







        // POST api/<CategoryController>
        [HttpPost]
        public async Task<IActionResult> Create(Models.Category types)
        {
            await _repository.AddAsync(types);
            return CreatedAtAction(nameof(GetByID), new { id = types.Id }, types);
        }







        // PUT api/<CategoryController>/5
        [HttpPut]
        public async Task<IActionResult> Update(Models.Category types)
        {
            //if(id!=items.ID) return BadRequest();
            await _repository.UpdateAsync(types);
            return NoContent();
        }






        // DELETE api/<CategoryController>/5
        [HttpDelete("{id}")]

        public async Task<IActionResult> Delete(int id)
        {
            await _repository.DeleteAsync(id);
            return NoContent();
        }
    }




}

