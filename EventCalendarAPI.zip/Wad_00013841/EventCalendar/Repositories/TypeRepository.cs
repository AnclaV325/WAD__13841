﻿using EventCalendar.Data;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using EventCalendar.Models;

namespace EventCalendar.Repositories
{


    public class TypeRepository : IRepository<Category>
    {
        private readonly EventCalendarDbContext _context;

        public TypeRepository(EventCalendarDbContext context)
        {
            _context = context;
        }

        // Add or create new entity
 

        public async Task AddAsync(Category entity)
        {
            await _context.Categories.AddAsync(entity);
            await _context.SaveChangesAsync();
        }

        // Delete an entity
        public async Task DeleteAsync(int id)
        {
            var entity = await _context.Categories.FindAsync(id);
            if (entity != null)
            {
                _context.Categories.Remove(entity);
                await _context.SaveChangesAsync();
            }
        }

        // Retrieve all entity from the database
        public async Task<IEnumerable<Category>> GetAllAsync() => await _context.Categories.ToArrayAsync();

        // Retrieve an entity from database using only an id
        public async Task<Category> GetByIDAsync(int id) => await _context.Categories.FindAsync(id);

        // Update the entity
        public async Task UpdateAsync(Category types)
        {
            _context.Entry(types).State = EntityState.Modified;
            await _context.SaveChangesAsync();
        }
    }


}

