﻿using EventCalendar.Data;
using EventCalendar.Models;
using Microsoft.EntityFrameworkCore;

namespace EventCalendar.Repositories
{
    public class EventsRepository : IRepository<Event>
    {

        private readonly EventCalendarDbContext _context;

        public EventsRepository(EventCalendarDbContext context)
        {
            _context = context;
        }


        public async Task<IEnumerable<Event>> GetAllAsync() => await _context.Events.Include(t => t.Type).ToArrayAsync();

     
        public async Task AddAsync(Event entity)
        {
         

            await _context.Events.AddAsync(entity);
            await _context.SaveChangesAsync();
        }

        public async Task DeleteAsync(int id)
        {
            var entity = await _context.Events.FindAsync(id);
            if (entity != null)
            {
                _context.Events.Remove(entity);
                await _context.SaveChangesAsync();
            }
        }

        

        public async Task<Event> GetByIDAsync(int id)
        {
            return await _context.Events.Include(t => t.Type).FirstOrDefaultAsync(t => t.id == id);
        }

        public async Task UpdateAsync(Event entity)
        {
            _context.Entry(entity).State = EntityState.Modified;
            await _context.SaveChangesAsync();
        }
    }
}
