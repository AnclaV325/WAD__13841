﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace EventCalendar.Data.Migrations
{
    public partial class categories : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "type",
                table: "Events");

            migrationBuilder.AddColumn<int>(
                name: "typeId",
                table: "Events",
                type: "int",
                nullable: true);

            migrationBuilder.CreateTable(
                name: "Categories",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Name = table.Column<string>(type: "nvarchar(max)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Categories", x => x.Id);
                });

            migrationBuilder.CreateIndex(
                name: "IX_Events_typeId",
                table: "Events",
                column: "typeId");

            migrationBuilder.AddForeignKey(
                name: "FK_Events_Categories_typeId",
                table: "Events",
                column: "typeId",
                principalTable: "Categories",
                principalColumn: "Id");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Events_Categories_typeId",
                table: "Events");

            migrationBuilder.DropTable(
                name: "Categories");

            migrationBuilder.DropIndex(
                name: "IX_Events_typeId",
                table: "Events");

            migrationBuilder.DropColumn(
                name: "typeId",
                table: "Events");

            migrationBuilder.AddColumn<string>(
                name: "type",
                table: "Events",
                type: "nvarchar(max)",
                nullable: false,
                defaultValue: "");
        }
    }
}
