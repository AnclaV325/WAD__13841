﻿using EventCalendar.Models;
using Microsoft.EntityFrameworkCore;

namespace EventCalendar.Data
{
    public class EventCalendarDbContext : DbContext
    {

        public EventCalendarDbContext(DbContextOptions<EventCalendarDbContext> options) : base(options) { }

        public DbSet<Event> Events { get; set; }
        public DbSet<Category> Categories { get; set; }

    }
}
