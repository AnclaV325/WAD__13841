﻿using System.ComponentModel.DataAnnotations;

namespace EventCalendar.Models
{
    public class Category
    {  //made by 00013841
        public int Id { get; set; }
        private string _name;
        [Required(ErrorMessage = "Name is required")]
        public string Name {
            
            get => _name; set 
            {
                if (string.IsNullOrWhiteSpace(value))
                {
                    throw new ArgumentException("Name cannot be null or empty.");
                }
                _name = value;
            
            
            }
        
        
        
        
        
        }






    }
}
