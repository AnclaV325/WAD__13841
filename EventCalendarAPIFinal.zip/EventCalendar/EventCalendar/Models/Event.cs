﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace EventCalendar.Models
{
    public class Event
    {  //made by 00013841
        [Required]
        public int id { get; set; }


        [Required(ErrorMessage ="Name is required")]
        public string name { get; set; }
        [Required(ErrorMessage ="Description is required")]
        public string? description { get; set; }


        public int? typeId { get; set; }
        [ForeignKey("typeId")]

        public Category? Type { get; set; }


        public string Date { get; set; }
    }
}
