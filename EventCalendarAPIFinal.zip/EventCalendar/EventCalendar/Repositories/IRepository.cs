﻿namespace EventCalendar.Repositories
{
    public interface IRepository <T>
    {  //made by 00013841
        Task<IEnumerable<T>> GetAllAsync();
        Task<T> GetByIDAsync(int it);
        Task AddAsync(T entity);
        Task UpdateAsync(T entity);
        Task DeleteAsync(int id);
    }
}
